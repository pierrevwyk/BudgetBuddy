# Budget Buddy

A simple, offline-first Android budgeting app for income, expenses, envelopes and reports.

## Tech
- Kotlin
- Jetpack Compose
- Material 3
- Room
- AndroidX ViewModel

## Open in Android Studio
1. Clone this repository.
2. Open the `BudgetBuddy` folder in Android Studio.
3. Let Gradle sync.
4. Connect your Android phone with USB debugging enabled.
5. Run the `app` configuration.

Default currency is South African Rand (ZAR).

## First version
- Dashboard
- Income and expense transactions
- Envelope/category budgets
- Local Room database
- Monthly totals
- Spending progress by category
