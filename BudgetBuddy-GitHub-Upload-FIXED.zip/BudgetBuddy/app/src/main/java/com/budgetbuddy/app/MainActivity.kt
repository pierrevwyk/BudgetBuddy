package com.budgetbuddy.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.List
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.PieChart
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import java.text.NumberFormat
import java.util.Locale
import kotlin.math.roundToLong

private fun money(cents: Long): String =
    NumberFormat.getCurrencyInstance(Locale("en", "ZA")).apply {
        currency = java.util.Currency.getInstance("ZAR")
    }.format(cents / 100.0)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { BudgetBuddyApp() }
    }
}

@Composable
fun BudgetBuddyApp(vm: BudgetViewModel = viewModel()) {
    var tab by remember { mutableIntStateOf(0) }
    var showAdd by remember { mutableStateOf(false) }
    var addType by remember { mutableStateOf("EXPENSE") }

    val transactions by vm.transactions.collectAsState()
    val budgets by vm.budgets.collectAsState()

    Scaffold(
        topBar = {
            Column(Modifier.padding(horizontal = 20.dp, vertical = 16.dp)) {
                Text("Budget Buddy", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                Text("Your money, your plan.", style = MaterialTheme.typography.bodyMedium)
            }
        },
        bottomBar = {
            NavigationBar {
                listOf(
                    Icons.Default.Home to "Home",
                    Icons.Default.List to "Transactions",
                    Icons.Default.PieChart to "Budgets",
                    Icons.Default.Settings to "Settings"
                ).forEachIndexed { index, item ->
                    NavigationBarItem(
                        selected = tab == index,
                        onClick = { tab = index },
                        icon = { Icon(item.first, item.second) },
                        label = { Text(item.second) }
                    )
                }
            }
        }
    ) { padding ->
        when (tab) {
            0 -> Dashboard(
                modifier = Modifier.padding(padding),
                transactions = transactions,
                onAdd = { addType = it; showAdd = true }
            )
            1 -> TransactionsScreen(Modifier.padding(padding), transactions, vm)
            2 -> BudgetsScreen(Modifier.padding(padding), budgets, transactions, vm)
            else -> SettingsScreen(Modifier.padding(padding))
        }
    }

    if (showAdd) {
        AddTransactionDialog(
            type = addType,
            onDismiss = { showAdd = false },
            onSave = { amount, category, description ->
                vm.addTransaction(amount, addType, category, description)
                showAdd = false
            }
        )
    }
}

@Composable
private fun Dashboard(
    modifier: Modifier,
    transactions: List<com.budgetbuddy.app.data.BudgetTransaction>,
    onAdd: (String) -> Unit
) {
    val income = transactions.filter { it.type == "INCOME" }.sumOf { it.amountCents }
    val expenses = transactions.filter { it.type == "EXPENSE" }.sumOf { it.amountCents }
    val balance = income - expenses

    Column(
        modifier.fillMaxSize().padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(20.dp)) {
                Text("Available balance", style = MaterialTheme.typography.labelLarge)
                Text(money(balance), style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                Text("Income  ${money(income)}")
                Text("Expenses  ${money(expenses)}")
            }
        }

        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Button(onClick = { onAdd("INCOME") }, modifier = Modifier.weight(1f)) {
                Icon(Icons.Default.Add, null)
                Spacer(Modifier.padding(3.dp))
                Text("Income")
            }
            OutlinedButton(onClick = { onAdd("EXPENSE") }, modifier = Modifier.weight(1f)) {
                Icon(Icons.Default.Add, null)
                Spacer(Modifier.padding(3.dp))
                Text("Expense")
            }
        }

        Text("Recent transactions", style = MaterialTheme.typography.titleLarge)
        if (transactions.isEmpty()) {
            Text("No transactions yet. Add your first income or expense.")
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(transactions.take(5), key = { it.id }) { tx ->
                    TransactionRow(tx, null)
                }
            }
        }
    }
}

@Composable
private fun TransactionsScreen(
    modifier: Modifier,
    transactions: List<com.budgetbuddy.app.data.BudgetTransaction>,
    vm: BudgetViewModel
) {
    LazyColumn(
        modifier.fillMaxSize().padding(horizontal = 20.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        item { Spacer(Modifier.height(4.dp)) }
        if (transactions.isEmpty()) {
            item { Text("No transactions yet.") }
        } else {
            items(transactions, key = { it.id }) { tx ->
                TransactionRow(tx) { vm.deleteTransaction(tx.id) }
            }
        }
    }
}

@Composable
private fun TransactionRow(
    tx: com.budgetbuddy.app.data.BudgetTransaction,
    onDelete: (() -> Unit)?
) {
    Card(Modifier.fillMaxWidth()) {
        Row(
            Modifier.fillMaxWidth().padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text(tx.category, fontWeight = FontWeight.Bold)
                if (tx.description.isNotBlank()) Text(tx.description)
            }
            Text(
                (if (tx.type == "INCOME") "+" else "-") + money(tx.amountCents),
                fontWeight = FontWeight.Bold
            )
            if (onDelete != null) {
                IconButton(onClick = onDelete) { Icon(Icons.Default.Delete, "Delete") }
            }
        }
    }
}

@Composable
private fun BudgetsScreen(
    modifier: Modifier,
    budgets: List<com.budgetbuddy.app.data.CategoryBudget>,
    transactions: List<com.budgetbuddy.app.data.BudgetTransaction>,
    vm: BudgetViewModel
) {
    var showBudget by remember { mutableStateOf(false) }

    Column(modifier.fillMaxSize().padding(20.dp)) {
        Button(onClick = { showBudget = true }) { Text("Add / update envelope") }
        Spacer(Modifier.height(14.dp))
        if (budgets.isEmpty()) Text("No envelopes yet. Create one for Food, Fuel, Bills, etc.")
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(budgets, key = { it.category }) { budget ->
                val spent = transactions.filter {
                    it.type == "EXPENSE" && it.category.equals(budget.category, true)
                }.sumOf { it.amountCents }
                val progress = if (budget.limitCents > 0) {
                    (spent.toFloat() / budget.limitCents).coerceIn(0f, 1f)
                } else 0f
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp)) {
                        Text(budget.category, fontWeight = FontWeight.Bold)
                        Text("${money(spent)} of ${money(budget.limitCents)}")
                        androidx.compose.material3.LinearProgressIndicator(
                            progress = { progress },
                            modifier = Modifier.fillMaxWidth().padding(top = 8.dp)
                        )
                    }
                }
            }
        }
    }

    if (showBudget) {
        BudgetDialog(
            onDismiss = { showBudget = false },
            onSave = { category, cents ->
                vm.saveBudget(category, cents)
                showBudget = false
            }
        )
    }
}

@Composable
private fun AddTransactionDialog(
    type: String,
    onDismiss: () -> Unit,
    onSave: (Long, String, String) -> Unit
) {
    var amount by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (type == "INCOME") "Add income" else "Add expense") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(amount, { amount = it }, label = { Text("Amount (R)") })
                OutlinedTextField(category, { category = it }, label = { Text("Category") })
                OutlinedTextField(description, { description = it }, label = { Text("Description") })
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val cents = (amount.replace(",", ".").toDoubleOrNull()?.times(100))?.roundToLong()
                if (cents != null && cents > 0) onSave(cents, category, description)
            }) { Text("Save") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

@Composable
private fun BudgetDialog(
    onDismiss: () -> Unit,
    onSave: (String, Long) -> Unit
) {
    var category by remember { mutableStateOf("") }
    var amount by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Budget envelope") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(category, { category = it }, label = { Text("Category") })
                OutlinedTextField(amount, { amount = it }, label = { Text("Monthly limit (R)") })
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val cents = amount.replace(",", ".").toDoubleOrNull()?.times(100)?.roundToLong()
                if (category.isNotBlank() && cents != null && cents >= 0) onSave(category.trim(), cents)
            }) { Text("Save") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

@Composable
private fun SettingsScreen(modifier: Modifier) {
    Column(modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Settings", style = MaterialTheme.typography.headlineSmall)
        Text("Currency: South African Rand (ZAR)")
        Text("Budget Buddy stores your data locally on this phone.")
        Text("Backup and restore will be added in the next version.")
    }
}
