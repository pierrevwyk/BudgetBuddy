package com.budgetbuddy.app

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.budgetbuddy.app.data.BudgetDatabase
import com.budgetbuddy.app.data.BudgetTransaction
import com.budgetbuddy.app.data.CategoryBudget
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class BudgetViewModel(app: Application) : AndroidViewModel(app) {
    private val dao = BudgetDatabase.get(app).budgetDao()

    val transactions = dao.observeTransactions()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val budgets = dao.observeBudgets()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun addTransaction(amountCents: Long, type: String, category: String, description: String) {
        viewModelScope.launch {
            dao.insertTransaction(
                BudgetTransaction(
                    amountCents = amountCents,
                    type = type,
                    category = category.ifBlank { "Other" },
                    description = description
                )
            )
        }
    }

    fun deleteTransaction(id: Long) {
        viewModelScope.launch { dao.deleteTransaction(id) }
    }

    fun saveBudget(category: String, limitCents: Long) {
        viewModelScope.launch {
            dao.upsertBudget(CategoryBudget(category.ifBlank { "Other" }, limitCents))
        }
    }
}
