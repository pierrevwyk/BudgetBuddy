package com.budgetbuddy.app.data

import android.content.Context
import androidx.room.Database
import androidx.room.Entity
import androidx.room.PrimaryKey
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.Dao
import androidx.room.Query
import androidx.room.Insert
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "transactions")
data class BudgetTransaction(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val amountCents: Long,
    val type: String, // INCOME or EXPENSE
    val category: String,
    val description: String,
    val dateMillis: Long = System.currentTimeMillis()
)

@Entity(tableName = "budgets")
data class CategoryBudget(
    @PrimaryKey val category: String,
    val limitCents: Long
)

@Dao
interface BudgetDao {
    @Query("SELECT * FROM transactions ORDER BY dateMillis DESC")
    fun observeTransactions(): Flow<List<BudgetTransaction>>

    @Insert
    suspend fun insertTransaction(transaction: BudgetTransaction)

    @Query("DELETE FROM transactions WHERE id = :id")
    suspend fun deleteTransaction(id: Long)

    @Query("SELECT * FROM budgets ORDER BY category")
    fun observeBudgets(): Flow<List<CategoryBudget>>

    @Insert
    suspend fun upsertBudget(budget: CategoryBudget)
}

@Database(
    entities = [BudgetTransaction::class, CategoryBudget::class],
    version = 1,
    exportSchema = false
)
abstract class BudgetDatabase : RoomDatabase() {
    abstract fun budgetDao(): BudgetDao

    companion object {
        @Volatile private var INSTANCE: BudgetDatabase? = null

        fun get(context: Context): BudgetDatabase =
            INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    BudgetDatabase::class.java,
                    "budget_buddy.db"
                ).build().also { INSTANCE = it }
            }
    }
}
