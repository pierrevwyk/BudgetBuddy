package com.budgetbuddy.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.budgetbuddy.app.data.*
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.roundToLong

private val CATS=listOf("Food","Groceries","Fuel","Transport","Rent","Mortgage","Electricity","Water","Internet","Phone","Insurance","Medical","School","Shopping","Entertainment","Subscriptions","Savings","Debt","Household","Other")
private fun money(c:Long)=NumberFormat.getCurrencyInstance(Locale("en","ZA")).apply{currency=Currency.getInstance("ZAR")}.format(c/100.0)
private fun date(m:Long)=SimpleDateFormat("dd MMM yyyy",Locale.getDefault()).format(Date(m))

class MainActivity:ComponentActivity(){
    override fun onCreate(b:Bundle?){super.onCreate(b);enableEdgeToEdge();setContent{App()}}
}

@Composable fun App(vm:BudgetViewModel=viewModel()){
    var tab by remember{mutableIntStateOf(0)};var add by remember{mutableStateOf(false)};var type by remember{mutableStateOf("EXPENSE")}
    val tx by vm.transactions.collectAsState();val budgets by vm.budgets.collectAsState();val recurring by vm.recurring.collectAsState()
    Scaffold(topBar={Column(Modifier.padding(20.dp)){Text("Budget Buddy",style=MaterialTheme.typography.headlineMedium,fontWeight=FontWeight.Bold);Text("Your money, your plan.")}},
        bottomBar={NavigationBar{listOf(Icons.Default.Home to "Home",Icons.Default.List to "Transactions",Icons.Default.PieChart to "Budgets",Icons.Default.Repeat to "Recurring",Icons.Default.Settings to "Settings").forEachIndexed{i,x->NavigationBarItem(
                    selected = tab == i,
                    onClick = { tab = i },
                    icon = { Icon(x.first, x.second) },
                    label = { Text(x.second) }
                )}}}
    ){p->when(tab){0->Home(Modifier.padding(p),tx){type=it;add=true};1->Transactions(Modifier.padding(p),tx,vm);2->Budgets(Modifier.padding(p),budgets,tx,vm);3->Recurring(Modifier.padding(p),recurring,vm);else->Settings(Modifier.padding(p))}}
    if(add)TransactionDialog(type,{add=false}){a,c,d->vm.addTransaction(a,type,c,d);add=false}
}

@Composable private fun Home(m:Modifier,tx:List<BudgetTransaction>,onAdd:(String)->Unit){
    val inc=tx.filter{it.type=="INCOME"}.sumOf{it.amountCents};val exp=tx.filter{it.type=="EXPENSE"}.sumOf{it.amountCents}
    Column(m.fillMaxSize().padding(20.dp),verticalArrangement=Arrangement.spacedBy(14.dp)){
        Card(Modifier.fillMaxWidth()){Column(Modifier.padding(20.dp)){Text("Available balance");Text(money(inc-exp),style=MaterialTheme.typography.headlineLarge,fontWeight=FontWeight.Bold);Text("Income  ${money(inc)}");Text("Expenses  ${money(exp)}")}}
        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(12.dp)){Button({onAdd("INCOME")},Modifier.weight(1f)){Text("+ Income")};OutlinedButton({onAdd("EXPENSE")},Modifier.weight(1f)){Text("+ Expense")}}
        Text("Recent transactions",style=MaterialTheme.typography.titleLarge)
        LazyColumn(verticalArrangement=Arrangement.spacedBy(8.dp)){items(tx.take(5),key={it.id}){TransactionRow(it,null)}}
    }
}
@Composable private fun Transactions(m:Modifier,tx:List<BudgetTransaction>,vm:BudgetViewModel){
    LazyColumn(m.fillMaxSize().padding(20.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){items(tx,key={it.id}){TransactionRow(it){vm.deleteTransaction(it.id)}}}
}
@Composable private fun TransactionRow(t:BudgetTransaction,del:(()->Unit)?){Card(Modifier.fillMaxWidth()){Row(Modifier.fillMaxWidth().padding(14.dp),verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text(t.category,fontWeight=FontWeight.Bold);if(t.description.isNotBlank())Text(t.description);Text(date(t.dateMillis),style=MaterialTheme.typography.labelSmall)};Text((if(t.type=="INCOME")"+" else "-")+money(t.amountCents),fontWeight=FontWeight.Bold);del?.let{IconButton({it()}){Icon(Icons.Default.Delete,"Delete")}}}}}

@Composable private fun Budgets(m:Modifier,b:List<CategoryBudget>,tx:List<BudgetTransaction>,vm:BudgetViewModel){
    var show by remember{mutableStateOf(false)}
    Column(m.fillMaxSize().padding(20.dp)){Button({show=true}){Text("Add / update envelope")};Spacer(Modifier.height(12.dp))
        LazyColumn(verticalArrangement=Arrangement.spacedBy(10.dp)){items(b,key={it.category}){x->
            val spent=tx.filter{it.type=="EXPENSE"&&it.category==x.category}.sumOf{it.amountCents};val rem=x.limitCents-spent
            Card(Modifier.fillMaxWidth()){Column(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(5.dp)){Text(x.category,fontWeight=FontWeight.Bold);Text("Spent: ${money(spent)} of ${money(x.limitCents)}");Text("Remaining: ${money(rem)}",fontWeight=FontWeight.Bold);LinearProgressIndicator({if(x.limitCents>0)(spent.toFloat()/x.limitCents).coerceIn(0f,1f)else 0f},Modifier.fillMaxWidth())}}
        }}
    }
    if(show)BudgetDialog({show=false}){c,a->vm.saveBudget(c,a);show=false}
}
@Composable private fun Recurring(m:Modifier,items:List<RecurringExpense>,vm:BudgetViewModel){
    var show by remember{mutableStateOf(false)}
    Column(m.fillMaxSize().padding(20.dp)){Button({show=true}){Text("+ Add recurring expense")};Spacer(Modifier.height(8.dp));Text("Press Paid after you pay a bill. The payment becomes an expense and the next due date moves forward.",style=MaterialTheme.typography.bodySmall);Spacer(Modifier.height(8.dp))
        LazyColumn(verticalArrangement=Arrangement.spacedBy(10.dp)){items(items,key={it.id}){e->Card(Modifier.fillMaxWidth()){Column(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(6.dp)){Row{Column(Modifier.weight(1f)){Text(e.description.ifBlank{e.category},fontWeight=FontWeight.Bold);Text(e.category)};Text(money(e.amountCents),fontWeight=FontWeight.Bold)};Text("Next due: ${date(e.nextDueMillis)}");Text("Frequency: "+e.frequency.lowercase().replaceFirstChar{it.uppercase()});Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){Button({vm.paid(e)}){Text("Paid")};OutlinedButton({vm.removeRecurring(e)}){Text("Remove")}}}}}}
    }
    if(show)RecurringDialog({show=false}){a,c,d,f,day->vm.addRecurring(a,c,d,f,day);show=false}
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable private fun Dropdown(value:String,label:String,options:List<String>,onPick:(String)->Unit){
    var open by remember{mutableStateOf(false)}
    ExposedDropdownMenuBox(open,{open=!open}){OutlinedTextField(value,{},readOnly=true,label={Text(label)},trailingIcon={ExposedDropdownMenuDefaults.TrailingIcon(open)},modifier=Modifier.fillMaxWidth().menuAnchor());ExposedDropdownMenu(open,{open=false}){options.forEach{o->DropdownMenuItem({Text(o)},{onPick(o);open=false})}}}
}
@Composable private fun TransactionDialog(type:String,dismiss:()->Unit,save:(Long,String,String)->Unit){
    var amount by remember{mutableStateOf("")};var cat by remember{mutableStateOf(CATS[0])};var desc by remember{mutableStateOf("")}
    AlertDialog(onDismissRequest=dismiss,title={Text(if(type=="INCOME")"Add income" else "Add expense")},text={Column(verticalArrangement=Arrangement.spacedBy(8.dp)){OutlinedTextField(amount,{amount=it},label={Text("Amount (R)")});Dropdown(cat,"Category",CATS){cat=it};OutlinedTextField(desc,{desc=it},label={Text("Description")})}},confirmButton={TextButton({amount.replace(",","." ).toDoubleOrNull()?.times(100)?.roundToLong()?.let{if(it>0)save(it,cat,desc)}}){Text("Save")}},dismissButton={TextButton(dismiss){Text("Cancel")}})
}
@Composable private fun BudgetDialog(dismiss:()->Unit,save:(String,Long)->Unit){
    var cat by remember{mutableStateOf(CATS[0])};var amount by remember{mutableStateOf("")}
    AlertDialog(onDismissRequest=dismiss,title={Text("Budget envelope")},text={Column(verticalArrangement=Arrangement.spacedBy(8.dp)){Dropdown(cat,"Category",CATS){cat=it};OutlinedTextField(amount,{amount=it},label={Text("Monthly limit (R)")})}},confirmButton={TextButton({amount.replace(",","." ).toDoubleOrNull()?.times(100)?.roundToLong()?.let{if(it>=0)save(cat,it)}}){Text("Save")}},dismissButton={TextButton(dismiss){Text("Cancel")}})
}
@Composable private fun RecurringDialog(dismiss:()->Unit,save:(Long,String,String,String,Int)->Unit){
    var amount by remember{mutableStateOf("")};var cat by remember{mutableStateOf(CATS[0])};var desc by remember{mutableStateOf("")};var freq by remember{mutableStateOf("MONTHLY")};var day by remember{mutableStateOf("1")}
    AlertDialog(onDismissRequest=dismiss,title={Text("Recurring expense")},text={Column(verticalArrangement=Arrangement.spacedBy(8.dp)){OutlinedTextField(amount,{amount=it},label={Text("Amount (R)")});Dropdown(cat,"Category",CATS){cat=it};OutlinedTextField(desc,{desc=it},label={Text("Description")});Dropdown(freq.lowercase().replaceFirstChar{it.uppercase()},"Frequency",listOf("Monthly","Weekly","Yearly")){freq=it.uppercase()};if(freq!="WEEKLY")OutlinedTextField(day,{day=it.filter(Char::isDigit).take(2)},label={Text("Due day (1-28)")})}},confirmButton={TextButton({val a=amount.replace(",","." ).toDoubleOrNull()?.times(100)?.roundToLong();if(a!=null&&a>0)save(a,cat,desc,freq,day.toIntOrNull()?.coerceIn(1,28)?:1)}){Text("Save")}},dismissButton={TextButton(dismiss){Text("Cancel")}})
}
@Composable private fun Settings(m:Modifier){Column(m.fillMaxSize().padding(20.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){Text("Settings",style=MaterialTheme.typography.headlineSmall);Text("Currency: South African Rand (ZAR)");Text("Categories are selectable to prevent spelling mistakes.");Text("Data is stored locally on this phone.")}}
