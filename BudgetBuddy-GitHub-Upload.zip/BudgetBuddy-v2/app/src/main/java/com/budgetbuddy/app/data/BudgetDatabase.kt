package com.budgetbuddy.app.data

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "transactions")
data class BudgetTransaction(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val amountCents: Long,
    val type: String,
    val category: String,
    val description: String,
    val dateMillis: Long = System.currentTimeMillis()
)

@Entity(tableName = "budgets")
data class CategoryBudget(
    @PrimaryKey val category: String,
    val limitCents: Long
)

@Entity(tableName = "recurring_expenses")
data class RecurringExpense(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val amountCents: Long,
    val category: String,
    val description: String,
    val frequency: String,
    val nextDueMillis: Long
)

@Dao
interface BudgetDao {
    @Query("SELECT * FROM transactions ORDER BY dateMillis DESC")
    fun observeTransactions(): Flow<List<BudgetTransaction>>
    @Insert suspend fun insertTransaction(t: BudgetTransaction)
    @Query("DELETE FROM transactions WHERE id=:id") suspend fun deleteTransaction(id: Long)

    @Query("SELECT * FROM budgets ORDER BY category")
    fun observeBudgets(): Flow<List<CategoryBudget>>
    @Insert(onConflict=OnConflictStrategy.REPLACE) suspend fun upsertBudget(b: CategoryBudget)

    @Query("SELECT * FROM recurring_expenses ORDER BY nextDueMillis")
    fun observeRecurringExpenses(): Flow<List<RecurringExpense>>
    @Insert suspend fun insertRecurringExpense(e: RecurringExpense)
    @Update suspend fun updateRecurringExpense(e: RecurringExpense)
    @Delete suspend fun deleteRecurringExpense(e: RecurringExpense)
}

@Database(entities=[BudgetTransaction::class, CategoryBudget::class, RecurringExpense::class], version=2, exportSchema=false)
abstract class BudgetDatabase : RoomDatabase() {
    abstract fun budgetDao(): BudgetDao
    companion object {
        @Volatile private var INSTANCE: BudgetDatabase? = null
        fun get(context: Context): BudgetDatabase = INSTANCE ?: synchronized(this) {
            INSTANCE ?: Room.databaseBuilder(context.applicationContext, BudgetDatabase::class.java, "budget_buddy.db")
                .addMigrations(object: Migration(1,2) {
                    override fun migrate(db: androidx.sqlite.db.SupportSQLiteDatabase) {
                        db.execSQL("""CREATE TABLE IF NOT EXISTS recurring_expenses (
                            id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                            amountCents INTEGER NOT NULL,
                            category TEXT NOT NULL,
                            description TEXT NOT NULL,
                            frequency TEXT NOT NULL,
                            nextDueMillis INTEGER NOT NULL
                        )""")
                    }
                }).build().also { INSTANCE = it }
        }
    }
}
