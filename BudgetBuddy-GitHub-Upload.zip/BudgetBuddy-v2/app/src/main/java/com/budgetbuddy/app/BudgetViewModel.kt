package com.budgetbuddy.app

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.budgetbuddy.app.data.*
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.Calendar

class BudgetViewModel(app: Application) : AndroidViewModel(app) {
    private val dao = BudgetDatabase.get(app).budgetDao()
    val transactions = dao.observeTransactions().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val budgets = dao.observeBudgets().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val recurring = dao.observeRecurringExpenses().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun addTransaction(a:Long,t:String,c:String,d:String)=viewModelScope.launch{dao.insertTransaction(BudgetTransaction(amountCents=a,type=t,category=c,description=d))}
    fun deleteTransaction(id:Long)=viewModelScope.launch{dao.deleteTransaction(id)}
    fun saveBudget(c:String,a:Long)=viewModelScope.launch{dao.upsertBudget(CategoryBudget(c,a))}
    fun addRecurring(a:Long,c:String,d:String,f:String,day:Int)=viewModelScope.launch{
        dao.insertRecurringExpense(RecurringExpense(amountCents=a,category=c,description=d,frequency=f,nextDueMillis=nextDue(f,day)))
    }
    fun removeRecurring(e:RecurringExpense)=viewModelScope.launch{dao.deleteRecurringExpense(e)}
    fun paid(e:RecurringExpense)=viewModelScope.launch{
        dao.insertTransaction(BudgetTransaction(amountCents=e.amountCents,type="EXPENSE",category=e.category,description=e.description))
        val c=Calendar.getInstance().apply{timeInMillis=e.nextDueMillis}
        when(e.frequency){"WEEKLY"->c.add(Calendar.WEEK_OF_YEAR,1);"YEARLY"->c.add(Calendar.YEAR,1);else->c.add(Calendar.MONTH,1)}
        dao.updateRecurringExpense(e.copy(nextDueMillis=c.timeInMillis))
    }
    private fun nextDue(f:String,day:Int):Long{
        val now=Calendar.getInstance()
        val c=Calendar.getInstance().apply{set(Calendar.HOUR_OF_DAY,12);set(Calendar.MINUTE,0);set(Calendar.SECOND,0);set(Calendar.MILLISECOND,0)}
        if(f=="WEEKLY") c.add(Calendar.DAY_OF_YEAR,7) else {
            c.set(Calendar.DAY_OF_MONTH,day.coerceIn(1,28))
            if(c.timeInMillis<=now.timeInMillis) if(f=="YEARLY") c.add(Calendar.YEAR,1) else c.add(Calendar.MONTH,1)
        }
        return c.timeInMillis
    }
}
