# Budget Buddy v2

Changes:
- Selectable fixed categories on income, expenses, envelopes and recurring bills.
- Each envelope shows its remaining amount.
- Recurring expenses with Monthly, Weekly and Yearly frequencies.
- Paid button records the recurring bill as an expense and advances the next due date.
- Room database migration from version 1 to version 2.
- Java/Kotlin JVM target 17 for GitHub builds.
