package com.budgetbuddy.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.budgetbuddy.app.data.*
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.roundToLong

val CATS=listOf("Food","Groceries","Fuel","Transport","Rent","Mortgage","Electricity","Water","Internet","Phone","Insurance","Medical","School","Shopping","Entertainment","Subscriptions","Savings","Debt","Household","Other")
private fun money(c:Long)=NumberFormat.getCurrencyInstance(Locale("en","ZA")).apply{currency=Currency.getInstance("ZAR")}.format(c/100.0)
private fun date(m:Long)=SimpleDateFormat("dd MMM yyyy",Locale.getDefault()).format(Date(m))

class MainActivity:ComponentActivity(){
    override fun onCreate(b:Bundle?){super.onCreate(b);enableEdgeToEdge();setContent{App()}}
}

@Composable fun App(vm: BudgetViewModel = viewModel()) {
    var tab by remember { mutableIntStateOf(0) }
    var addExpense by remember { mutableStateOf(false) }
    var editBalance by remember { mutableStateOf(false) }
    val tx by vm.transactions.collectAsState()
    val budgets by vm.budgets.collectAsState()
    val startingBalance by vm.startingBalanceCents.collectAsState()
    val customCategories by vm.customCategories.collectAsState()
    val categories = remember(customCategories) { (CATS + customCategories).distinct() }

    Scaffold(
        topBar = {
            Column(Modifier.padding(20.dp)) {
                Text("Budget Buddy", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                Text("Your money, your plan.")
            }
        },
        bottomBar = {
            NavigationBar {
                listOf(
                    Icons.Default.Home to "Home",
                    Icons.Default.List to "Transactions",
                    Icons.Default.PieChart to "Budgets",
                    Icons.Default.Settings to "Settings"
                ).forEachIndexed { i, x ->
                    NavigationBarItem(
                        selected = tab == i,
                        onClick = { tab = i },
                        icon = { Icon(x.first, x.second) },
                        label = { Text(x.second) }
                    )
                }
            }
        }
    ) { p ->
        when (tab) {
            0 -> Home(Modifier.padding(p), tx, budgets, startingBalance, { editBalance = true }, { addExpense = true })
            1 -> Transactions(Modifier.padding(p), tx, vm)
            2 -> Budgets(Modifier.padding(p), budgets, tx, vm, categories)
            else -> Settings(Modifier.padding(p), categories, vm)
        }
    }

    if (addExpense) {
        TransactionDialog(categories, { addExpense = false }) { amount, category, description ->
            vm.addExpense(amount, category, description)
            addExpense = false
        }
    }

    if (editBalance) {
        BalanceDialog(startingBalance, { editBalance = false }) { amount ->
            vm.setAvailableBalance(amount, tx)
            editBalance = false
        }
    }
}

@Composable private fun Home(
    m: Modifier,
    tx: List<BudgetTransaction>,
    budgets: List<CategoryBudget>,
    startingBalance: Long,
    onEditBalance: () -> Unit,
    onAddExpense: () -> Unit
) {
    val inc = tx.filter { it.type == "INCOME" }.sumOf { it.amountCents }
    val exp = tx.filter { it.type == "EXPENSE" }.sumOf { it.amountCents }
    val available = startingBalance + inc - exp
    val envelopeTotal = budgets.sumOf { it.limitCents }
    val remainingAfterEnvelopes = available - envelopeTotal

    Column(m.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Available balance")
                        Text(money(available), style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold)
                    }
                    IconButton(onClick = onEditBalance) {
                        Icon(Icons.Default.Edit, contentDescription = "Edit available balance")
                    }
                }
                Text("Tap the pencil to change the available balance.", style = MaterialTheme.typography.bodySmall)
                if (inc > 0) Text("Recorded income  ${money(inc)}")
                Text("Expenses  ${money(exp)}")
                HorizontalDivider(Modifier.padding(vertical = 4.dp))
                Text("Total envelopes  ${money(envelopeTotal)}")
                Text("Remaining after envelopes", style = MaterialTheme.typography.titleMedium)
                Text(money(remainingAfterEnvelopes), style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            }
        }

        Button(onClick = onAddExpense, modifier = Modifier.fillMaxWidth()) {
            Text("+ Expense")
        }

        Text("Recent transactions", style = MaterialTheme.typography.titleLarge)
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(tx.take(5), key = { it.id }) { TransactionRow(it, null) }
        }
    }
}

@Composable private fun BalanceDialog(
    currentCents: Long,
    dismiss: () -> Unit,
    save: (Long) -> Unit
) {
    var amount by remember { mutableStateOf(if (currentCents == 0L) "" else String.format(Locale.US, "%.2f", currentCents / 100.0)) }
    AlertDialog(
        onDismissRequest = dismiss,
        title = { Text("Available balance") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Enter the amount currently available to you.")
                OutlinedTextField(
                    value = amount,
                    onValueChange = { amount = it },
                    label = { Text("Amount (R)") },
                    singleLine = true
                )
            }
        },
        confirmButton = {
            TextButton({
                amount.replace(",", ".").toDoubleOrNull()?.times(100)?.roundToLong()?.let { if (it >= 0) save(it) }
            }) { Text("Save") }
        },
        dismissButton = { TextButton(dismiss) { Text("Cancel") } }
    )
}

@Composable private fun TransactionDialog(categories: List<String>, dismiss: () -> Unit, save: (Long, String, String) -> Unit) {
    var amount by remember { mutableStateOf("") }
    var cat by remember { mutableStateOf(categories.first()) }
    var desc by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = dismiss,
        title = { Text("Add expense") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(amount, { amount = it }, label = { Text("Amount (R)") })
                Dropdown(cat, "Category", categories) { cat = it }
                OutlinedTextField(desc, { desc = it }, label = { Text("Description") })
            }
        },
        confirmButton = {
            TextButton({
                amount.replace(",", ".").toDoubleOrNull()?.times(100)?.roundToLong()?.let { if (it > 0) save(it, cat, desc) }
            }) { Text("Save") }
        },
        dismissButton = { TextButton(dismiss) { Text("Cancel") } }
    )
}

@Composable private fun Transactions(m:Modifier,tx:List<BudgetTransaction>,vm:BudgetViewModel){
    LazyColumn(m.fillMaxSize().padding(20.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){items(tx,key={it.id}){TransactionRow(it){vm.deleteTransaction(it.id)}}}
}
@Composable private fun TransactionRow(t:BudgetTransaction,del:(()->Unit)?){Card(Modifier.fillMaxWidth()){Row(Modifier.fillMaxWidth().padding(14.dp),verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text(t.category,fontWeight=FontWeight.Bold);if(t.description.isNotBlank())Text(t.description);Text(date(t.dateMillis),style=MaterialTheme.typography.labelSmall)};Text((if(t.type=="INCOME")"+" else "-")+money(t.amountCents),fontWeight=FontWeight.Bold);del?.let{IconButton({it()}){Icon(Icons.Default.Delete,"Delete")}}}}}

@Composable private fun Budgets(m:Modifier,b:List<CategoryBudget>,tx:List<BudgetTransaction>,vm:BudgetViewModel,categories:List<String>){
    var show by remember{mutableStateOf(false)}
    Column(m.fillMaxSize().padding(20.dp)){Button({show=true}){Text("Add / update envelope")};Spacer(Modifier.height(12.dp))
        LazyColumn(verticalArrangement=Arrangement.spacedBy(10.dp)){items(b,key={it.category}){x->
            val spent=tx.filter{it.type=="EXPENSE"&&it.category==x.category}.sumOf{it.amountCents};val rem=x.limitCents-spent
            Card(Modifier.fillMaxWidth()){Column(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(5.dp)){Text(x.category,fontWeight=FontWeight.Bold);Text("Spent: ${money(spent)} of ${money(x.limitCents)}");Text("Remaining: ${money(rem)}",fontWeight=FontWeight.Bold);LinearProgressIndicator(progress = { if (x.limitCents > 0) (spent.toFloat() / x.limitCents).coerceIn(0f, 1f) else 0f }, modifier = Modifier.fillMaxWidth())}}
        }}
    }
    if(show)BudgetDialog(categories, {show=false}){c,a->vm.saveBudget(c,a);show=false}
}
@Composable
private fun Dropdown(value: String, label: String, options: List<String>, onPick: (String) -> Unit) {
    var open by remember { mutableStateOf(false) }
    Box {
        OutlinedButton(onClick = { open = true }, modifier = Modifier.fillMaxWidth()) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Column(horizontalAlignment = Alignment.Start) {
                    Text(label, style = MaterialTheme.typography.labelSmall)
                    Text(value)
                }
                Icon(Icons.Default.ArrowDropDown, contentDescription = null)
            }
        }
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            options.forEach { option ->
                DropdownMenuItem(
                    text = { Text(option) },
                    onClick = { onPick(option); open = false }
                )
            }
        }
    }
}
@Composable private fun BudgetDialog(categories: List<String>, dismiss:()->Unit,save:(String,Long)->Unit){
    var cat by remember{mutableStateOf(categories.first())};var amount by remember{mutableStateOf("")}
    AlertDialog(onDismissRequest=dismiss,title={Text("Budget envelope")},text={Column(verticalArrangement=Arrangement.spacedBy(8.dp)){Dropdown(cat,"Category",categories){cat=it};OutlinedTextField(amount,{amount=it},label={Text("Monthly limit (R)")})}},confirmButton={TextButton({amount.replace(",","." ).toDoubleOrNull()?.times(100)?.roundToLong()?.let{if(it>=0)save(cat,it)}}){Text("Save")}},dismissButton={TextButton(dismiss){Text("Cancel")}})
}

@Composable
private fun Settings(m: Modifier, categories: List<String>, vm: BudgetViewModel) {
    var showAddCategory by remember { mutableStateOf(false) }
    Column(
        m.fillMaxSize().padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text("Settings", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Budget Buddy", fontWeight = FontWeight.Bold)
                Text("Simple budgeting for everyday spending.")
                Text("Categories are selectable to help prevent spelling mistakes.")
                Button(onClick = { showAddCategory = true }, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Default.Add, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text("Add my own category")
                }
            }
        }
        if (categories.any { it !in CATS }) {
            Text("My categories", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Text(categories.filter { it !in CATS }.joinToString(" • "))
        }
    }
    if (showAddCategory) {
        AddCategoryDialog(
            dismiss = { showAddCategory = false },
            save = { name ->
                val added = vm.addCustomCategory(name)
                if (added) showAddCategory = false
                added
            }
        )
    }
}

@Composable
private fun AddCategoryDialog(dismiss: () -> Unit, save: (String) -> Boolean) {
    var name by remember { mutableStateOf("") }
    var error by remember { mutableStateOf(false) }
    AlertDialog(
        onDismissRequest = dismiss,
        title = { Text("Add category") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Create a category that will appear in the category list for expenses and envelopes.")
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it; error = false },
                    label = { Text("Category name") },
                    singleLine = true,
                    isError = error
                )
                if (error) Text("Enter a new category name.", color = MaterialTheme.colorScheme.error)
            }
        },
        confirmButton = {
            TextButton(onClick = { if (!save(name)) error = true }) { Text("Add") }
        },
        dismissButton = { TextButton(onClick = dismiss) { Text("Cancel") } }
    )
}
