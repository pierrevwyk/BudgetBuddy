package com.budgetbuddy.app

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.budgetbuddy.app.data.*
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class BudgetViewModel(app: Application) : AndroidViewModel(app) {
    private val dao = BudgetDatabase.get(app).budgetDao()
    val transactions = dao.observeTransactions().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val budgets = dao.observeBudgets().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun addTransaction(a:Long,t:String,c:String,d:String)=viewModelScope.launch{dao.insertTransaction(BudgetTransaction(amountCents=a,type=t,category=c,description=d))}
    fun deleteTransaction(id:Long)=viewModelScope.launch{dao.deleteTransaction(id)}
    fun saveBudget(c:String,a:Long)=viewModelScope.launch{dao.upsertBudget(CategoryBudget(c,a))}
}
