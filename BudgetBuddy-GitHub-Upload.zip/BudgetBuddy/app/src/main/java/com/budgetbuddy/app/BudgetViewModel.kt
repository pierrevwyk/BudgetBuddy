package com.budgetbuddy.app

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.budgetbuddy.app.data.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class BudgetViewModel(app: Application) : AndroidViewModel(app) {
    private val dao = BudgetDatabase.get(app).budgetDao()
    private val prefs = app.getSharedPreferences("budget_buddy_settings", Context.MODE_PRIVATE)

    val transactions = dao.observeTransactions().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val budgets = dao.observeBudgets().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _startingBalanceCents = MutableStateFlow(prefs.getLong("starting_balance_cents", 0L))
    val startingBalanceCents = _startingBalanceCents.stateIn(viewModelScope, SharingStarted.Eagerly, _startingBalanceCents.value)

    fun setAvailableBalance(amountCents: Long, transactions: List<BudgetTransaction>) {
        val safeAmount = amountCents.coerceAtLeast(0L)
        val income = transactions.filter { it.type == "INCOME" }.sumOf { it.amountCents }
        val expenses = transactions.filter { it.type == "EXPENSE" }.sumOf { it.amountCents }
        val baseBalance = safeAmount - income + expenses
        prefs.edit().putLong("starting_balance_cents", baseBalance).apply()
        _startingBalanceCents.value = baseBalance
    }

    fun addExpense(a: Long, c: String, d: String) = viewModelScope.launch {
        dao.insertTransaction(BudgetTransaction(amountCents = a, type = "EXPENSE", category = c, description = d))
    }

    fun deleteTransaction(id: Long) = viewModelScope.launch { dao.deleteTransaction(id) }
    fun saveBudget(c: String, a: Long) = viewModelScope.launch { dao.upsertBudget(CategoryBudget(c, a)) }
}
