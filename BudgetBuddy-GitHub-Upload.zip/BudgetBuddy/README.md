# Budget Buddy v2

Changes:
- Selectable fixed categories on income, expenses and envelopes.
- Each envelope shows its remaining amount.
- Room database migration from version 1 to version 2.
- Java/Kotlin JVM target 17 for GitHub builds.

- Recurring expenses have been removed from the user interface. The old database table is retained only for safe upgrades from earlier versions.


### Home balance
The Home screen shows the total assigned to envelopes and the remaining amount after subtracting envelope totals from the available balance.
